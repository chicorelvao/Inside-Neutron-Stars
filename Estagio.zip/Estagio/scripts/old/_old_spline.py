"""
FICHEIROS NECESSÁRIOS:
#tov.out para uma estrela
#fort.75 com a densidade de particulas

DESCRIÇÃO:

VARIÁVEIS NOS COMENTÁRIOS:
rho(b) - densidade barionica
y(i) - quantidade de particulas de cada especie

"""

from scipy import interpolate
import numpy as np 
import matplotlib.pyplot as plt


#______________________________________________________________________

#Ler o ficheiro fort.75 que contem a densidade de particulas para barions (e outros...)
# e o ficheiro tov_s1_____.out que contem a densidade barionica e o raio da estrela.
inputRho = open("/home/chico/Documents/Estagio/SplinePy/DATA/fort.75", "r") 
inputR = open("/home/chico/Documents/Estagio/SplinePy/DATA/tov_s1_m1.out", "r") 
#Transformar os valores do ficheiros em arrays
#ficheiro fort.75
fileRho = inputRho.readlines()

#ficheiro tov_s1_____.out

fileR = inputR.readlines()


#______________________________________________________________________
#selecionar a DATA útil de entrada

#ciclos para ler o documento que contem o raio
#O documento é lido por lista com linhas do tipo string.
#Depois é removido os espaço que separam as colunas e de seguida é construidas matrizes
#de numeros reais.


#file tov_s1____.out   

R = np.array([0]) #array que contem todos os raios

for line in fileR:
	lineCut = line.split(" ")
	while "" in lineCut:
		lineCut.remove("")
	R = np.vstack((R,float(lineCut[0])))

R = np.delete(R, 0)


#ciclo para ler a densidade barionica do file tov_s1____.out
rhoBtov = np.array([0]) #array que contem todas as densidades barionicas

for lineS in fileR:
	lineCutS = lineS.split(" ")
	while "" in lineCutS:
		lineCutS.remove("")
	rhoBtov = np.vstack((rhoBtov ,float(lineCutS[3])))

rhoBtov = np.delete(rhoBtov, 0)


#file fort.75
#ciclo para ler a densidade barionica do ficheiro fort.75


rhoBfort = np.array([0]) #array que contem todas as densidade neutroes

for line in fileRho:
	line = line.split(" ")
	while "" in line:
		line.remove("")
	rhoBfort = np.vstack((rhoBfort,float(line[0])))

rhoBfort = np.delete(rhoBfort, 0)

#ciclo para ler a quantidade de neutroes

rhoN = np.array([0]) #array que contem todas as densidade neutroes

for line in fileRho:
	line = line.split(" ")
	while "" in line:
		line.remove("")
	rhoN = np.vstack((rhoN,float(line[1])))

rhoN = np.delete(rhoN, 0)

#ciclo para ler a quantidade de protoes

rhoP = np.array([0]) #array que contem todas as densidade protoes

for line in fileRho:
	line = line.split(" ")
	while "" in line:
		line.remove("")
	rhoP = np.vstack((rhoP,float(line[2])))

rhoP = np.delete(rhoP, 0)

#______________________________________________________________________
#calculo da fração de particulas
# frac(i) = rho(i) / rho(b)
#fração de neutroes

fracN = np.divide(rhoN, rhoBfort)
fracP = np.divide(rhoP, rhoBfort)



#--------criar algoritmo para sort----------
dtsort = np.array([1,2,4,7,9])


#______________________________________________________________________



realX = R #definição do eixo do x que queremos: Raio
resolX = 0.0001 #resolução do x
midY = rhoBtov # definição do valor que faz a ligação entre o raio e a fração de particulas: a densidade barionica do tov_s1____.out
midX = rhoBfort # o mesmo que a variavel midY. Desta vez, é a densB de fort.75. A relação de r e frac, defini se entre as variaveis rhoBtov e rhoBfort

realY = fracP#definição do eixo do y que queremos: fração de particulas

#spline entre o raio e rho(b)tov, return dos coeficientes nos respectivos intervalos a aplicar
coef_Intp = interpolate.splrep(realX, midY, s=0)

#construção de um eixo do x relativamente contínuo. O ultimo parametro define a resolução

contX = np.arange(R[0], R[-1], resolX)
#interpolação para todos os valores do eixo do x referido e do mid Y. Ou seja, construção do eixo do x para a proxima interpolação
# x = R / y = rhoBtov = middleX
middleX = interpolate.splev(contX, coef_Intp, der=0)


#spline entre o rhoBfort e frac, return dos coeficientes nos respectivos intervalos a aplicar
coef_Sec_Intp= interpolate.splrep(midX, realY, s=0) #certo

#interpolação para todos os valores do eixo de um novo eixo do x. Ou seja, construção de um novo eixo do y
contY= interpolate.splev(middleX, coef_Sec_Intp, der=0)


#construção do gráfico
plt.figure()
xLine = contX
yLine = contY
#valores finais
#x = r / y = y(i)

plt.plot(xLine, yLine)
plt.axis([0,15, 0, 1])
plt.show()

#-------------------muito importante---------------
#fechar o file
inputRho.close()
